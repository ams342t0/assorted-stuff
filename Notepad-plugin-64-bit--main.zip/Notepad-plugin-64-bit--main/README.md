# Notepad-plugin-64-bit-
x86_64 opcode quick reference using NPPM_GETCURRENTWORD message and sqlite. Derived from Notepad++ plugin template.
https://npp-user-manual.org/
