# jcalc
java infix arithmetic expression calculator
