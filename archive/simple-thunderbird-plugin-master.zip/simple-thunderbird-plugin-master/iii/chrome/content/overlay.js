function say_hi()
{
	var n = gFolderDisplay.selectedMessage;
	if (n)
	{
		prompt("COPY IT",n.author.substring(n.author.search("<")+1,n.author.search(">")));
	}
}