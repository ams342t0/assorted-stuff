# simple-thunderbird-plugin
access email address quickly through a context menu
