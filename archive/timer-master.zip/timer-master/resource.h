//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by winres.rc
//
#define IDD_FORMVIEW                    101
#define IDR_MENU1                       101
#define IDR_MENU2                       103
#define IDR_ACCELERATOR1                107
#define IDI_ICON2                       108
#define IDB_BITMAP1                     109
#define IDI_ICON1                       110
#define IDC_HOUR                        1000
#define IDC_MINUTE                      1001
#define IDC_SECONDS                     1002
#define IDC_RUN                         1003
#define IDC_TITLE                       1004
#define IDC_LIST1                       1005
#define IDC_ADD                         1006
#define IDC_DELETE                      1007
#define IDC_ALARM                       1008
#define ID_ALARM                        40001
#define ID_TITLECOLOR                   40002
#define ID_TIMECOLOR                    40003
#define ID_BACKGROUND                   40004
#define ID_ALTS                         40005
#define ID_ALTT                         40006
#define IDSHUTDOWN                      40007

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        111
#define _APS_NEXT_COMMAND_VALUE         40008
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
